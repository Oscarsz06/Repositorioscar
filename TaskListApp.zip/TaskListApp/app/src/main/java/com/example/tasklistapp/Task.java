package com.example.tasklistapp;

public class Task {
    private String name;
    private String category;
    private String status;

    public Task(String name, String category, String status) {
        this.name = name;
        this.category = category;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public String getStatus() {
        return status;
    }
}
