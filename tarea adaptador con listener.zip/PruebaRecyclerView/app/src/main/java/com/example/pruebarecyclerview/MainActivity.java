package com.example.pruebarecyclerview;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pruebarecyclerview.adaptadores.UsuarioAdaptador;
import com.example.pruebarecyclerview.clases.Usuario;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv_usuarios;
    List<Usuario> listaUsuarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv_usuarios = findViewById(R.id.rcv_usuarios);

        Usuario usu1 = new Usuario("https://rickandmortyapi.com/api/character/avatar/72.jpeg","Ruben","Movil");
        Usuario usu2 = new Usuario("https://rickandmortyapi.com/api/character/avatar/120.jpeg","Enzo","Chelsea");
        Usuario usu3 = new Usuario("https://rickandmortyapi.com/api/character/avatar/190.jpeg","Modric","Real Madrid");


        listaUsuarios.add(usu1);
        listaUsuarios.add(usu2);
        listaUsuarios.add(usu3);

        rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));
        rcv_usuarios.setAdapter(new UsuarioAdaptador(listaUsuarios, new UsuarioAdaptador.OnItemClickListener() {
            @Override
            public void onItemClick(Usuario usuario) {
                switch (usuario.getCurso()) {  // Suponiendo que 'getCurso()' devuelve un identificador único de acción
                    case "Movil":
                        startActivity(new Intent(MainActivity.this, MainActivity2.class));
                        break;
                    case "Chelsea":
                        startActivity(new Intent(MainActivity.this, MainActivity3.class));
                        break;
                    case "Real Madrid":
                        startActivity(new Intent(MainActivity.this, MainActivity4.class));
                        break;
                }
            }
        }));

    }
}