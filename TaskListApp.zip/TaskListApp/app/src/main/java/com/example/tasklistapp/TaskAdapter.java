package com.example.tasklistapp;

import androidx.recyclerview.widget.RecyclerView;

public class TaskAdapter extends RecyclerView.Adapter {


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

    public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
        private List<Task> taskList;
        private Context context;

        public TaskAdapter(Context context, List<Task> taskList) {
            this.taskList = taskList;
            this.context = context;
        }

        @NonNull
        @Override
        public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_task, parent, false);
            return new TaskViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
            Task task = taskList.get(position);
            holder.tvTaskName.setText(task.getName());
            holder.tvTaskCategory.setText(task.getCategory());


            switch (task.getStatus()) {
                case "Pendiente":
                    holder.tvTaskStatus.setTextColor(context.getResources().getColor(R.color.statusPending));
                    break;
                case "Completada":
                    holder.tvTaskStatus.setTextColor(context.getResources().getColor(R.color.statusCompleted));
                    break;
                case "En progreso":
                    holder.tvTaskStatus.setTextColor(context.getResources().getColor(R.color.statusInProgress));
                    break;
            }
            holder.tvTaskStatus.setText(task.getStatus());

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, TaskDetailActivity.class);
                intent.putExtra("name", task.getName());
                intent.putExtra("category", task.getCategory());
                intent.putExtra("status", task.getStatus());
                context.startActivity(intent);
            });
        }
