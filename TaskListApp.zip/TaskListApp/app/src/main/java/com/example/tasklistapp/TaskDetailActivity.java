package com.example.tasklistapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TaskDetailActivity extends AppCompatActivity {
    private TextView tvDetailName, tvDetailCategory, tvDetailStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks_detail);

        tvDetailName = findViewById(R.id.tvDetailName);
        tvDetailCategory = findViewById(R.id.tvDetailCategory);
        tvDetailStatus = findViewById(R.id.tvDetailStatus);


        String name = getIntent().getStringExtra("name");
        String category = getIntent().getStringExtra("category");
        String status = getIntent().getStringExtra("status");

        tvDetailName.setText(name);
        tvDetailCategory.setText(category);
        tvDetailStatus.setText(status);
    }
}